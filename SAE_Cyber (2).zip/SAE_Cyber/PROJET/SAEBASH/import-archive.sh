#!/bin/bash

# Vérifier qu'au moins un paramètre est passé
if [ $# -lt 1 ]; then
    echo "Erreur : vous n'avez pas passé de paramètres"
    exit 2
fi

# Vérifier que le dossier .sh-toolbox existe
if [ ! -d ".sh-toolbox" ]; then
    echo "Erreur : le dossier .sh-toolbox n'existe pas"
    exit 1
fi

# Mode force ?
MODE_FORCE=0
if [ "$1" = "-f" ]; then
    MODE_FORCE=1
    shift  # enlevé -f des paramètres
fi

# Vérifier qu'il reste au moins une archive
if [ $# -lt 1 ]; then
    echo "Erreur : aucune archive à importer"
    exit 2
fi

FICHIER_ARCHIVES=".sh-toolbox/archives"
if [ ! -f "$FICHIER_ARCHIVES" ]; then
    echo "0" > "$FICHIER_ARCHIVES"
fi

# Lire le compteur actuel
COMPTEUR=$(head -n 1 "$FICHIER_ARCHIVES")

# Boucle sur toutes les archives passées en paramètre
for CHEMIN_ARCHIVE in "$@"; do
    # Vérifier que l'archive existe
    if [ ! -f "$CHEMIN_ARCHIVE" ]; then
        echo "Erreur : L'archive $CHEMIN_ARCHIVE n'existe pas"
        continue
    fi

    NOM_ARCHIVE=$(basename "$CHEMIN_ARCHIVE")
    AJOUT_REUSSI=0 # Indicateur : 1 si une NOUVELLE entrée doit être ajoutée

    # Vérifier si un fichier du même nom existe déjà dans la toolbox
    if [ -f ".sh-toolbox/$NOM_ARCHIVE" ]; then
        if [ $MODE_FORCE -eq 1 ]; then
            # Écrasement en mode force. L'entrée dans archives ne bouge pas.
            # Écrasement manuel. L'entrée dans archives ne bouge pas.
                cp "$CHEMIN_ARCHIVE" ".sh-toolbox/$NOM_ARCHIVE"
                echo "Le fichier $NOM_ARCHIVE a été écrasé."
            else
                echo "Copie annulée pour $NOM_ARCHIVE."
                continue
            fi
    else
        # C'est une NOUVELLE archive
        cp "$CHEMIN_ARCHIVE" ".sh-toolbox/$NOM_ARCHIVE"
        echo "Archive $NOM_ARCHIVE copiée avec succès."
        AJOUT_REUSSI=1 # On marque qu'il faut mettre à jour les métadonnées
    fi

    # Mise à jour du fichier archives (conditionnelle)
    if [ $AJOUT_REUSSI -eq 1 ]; then
        COMPTEUR=$((COMPTEUR+1))
        DATE_IMPORT=$(date +"%Y%m%d-%H%M%S")
        {
            echo "$COMPTEUR"
            tail -n +2 "$FICHIER_ARCHIVES"
            echo "$NOM_ARCHIVE:$DATE_IMPORT:"
        } > "$FICHIER_ARCHIVES.tmp" && mv "$FICHIER_ARCHIVES.tmp" "$FICHIER_ARCHIVES"

        if [ $? -ne 0 ]; then
            echo "Erreur : problème lors de la mise à jour du fichier archives"
            exit 4
        fi
        echo "Le fichier archives a été mis à jour pour $NOM_ARCHIVE."
    fi
done

exit 0

