#include "crypto.h"

int main(int argc, char *argv[])
{
    if (argc != 3) {
        fprintf(stderr, "Utilisation : %s <cle_base64> <fichier_base64>\n", argv[0]);
        return 1;
    }

    const char *cle = argv[1];
    const char *nomfichier = argv[2];

    FILE *f = fopen(nomfichier, "r");
    if (!f) {
        perror("Erreur ouverture");
        return 1;
    }

    // Lecture intégrale
    fseek(f, 0, SEEK_END);//se positionner a la fin
    long taille = ftell(f);// lire la position de fin
    rewind(f);// retourner au debut 

    char *entree = malloc(taille + 1); //
    
    
    char *sortie = malloc(taille + 1);

    fread(entree, 1, taille, f);
    entree[taille] = '\0';
    fclose(f);

    //  suppression du retour à la ligne final
    long len = strlen(entree);
    if (len > 0 && (entree[len-1] == '\n' || entree[len-1] == '\r')) {
        sortie[len-1] = '\0';
        len--;
    }

    // Chiffrement
    vigenereEnc(entree, cle, sortie);

    // Réécriture dans le même fichier
    f = fopen(nomfichier, "w");
    fwrite(sortie, 1, strlen(sortie), f);
    fclose(f);

    free(entree);
    free(sortie);

    printf("Chiffrement terminé.\n");
    return 0;
}
