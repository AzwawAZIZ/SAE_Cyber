# Guide d'utilisation des programmes C – SAE3

Ce document décrit les programmes C utilisés par les scripts Bash de la boîte à outils.  
Ils permettent la recherche de clé et le déchiffrement de fichiers chiffrés en Base64.



## 1. Architecture du dossier `src/`


src/
├── decipher.c
├── findkey.c
├── crypto.c
├── crypto.h
├── Makefile
└── libcrypto/      


Les binaires générés (`decipher` et `findkey`) sont placés à la racine du projet.



## 2. Compilation

### Avec Makefile :

cd src
make


Génère les binaires `decipher` et `findkey`.

### Sans Makefile :

gcc decipher.c crypto.c -o decipher
gcc findkey.c crypto.c -o findkey




## 3. Programme `findkey` — Recherche de clé

### Commande :

./findkey clair.b64 chiffre.b64 [-o fichier]


### Fonction :
Déduit automatiquement la clé Vigenère mod 64 utilisée pour chiffrer un fichier.

### Entrées :
- `clair.b64` : version en Base64 du fichier original,
- `chiffre.b64` : version chiffrée en Base64.

### Sorties :
- clé affichée sur **stdout**,
- taille de la clé affichée sur **stderr**,
- possibilité d’écrire la clé dans un fichier via l’option `-o`.

### Particularités :
- gère les clés binaires non imprimables,
- fonctionne sur des fichiers de tailles identiques.



## 4. Programme `decipher` — Déchiffrement

### Commande :

./decipher fichier_chiffre.b64 cle [-o fichier_sortie]
```

### Fonction :
Déchiffre un fichier chiffré en Base64 à l’aide d’une clé Vigenère mod 64.

### Entrées :
- fichier chiffré en Base64,
- clé (chaîne ou contenu binaire),
- option `-o` pour définir le fichier de sortie.

### Sortie :
- fichier déchiffré en clair.

---

## 5. Bibliothèque `crypto.c`

Le fichier `crypto.c` (associé à `crypto.h`) contient les fonctions cryptographiques utilisées par les deux programmes :

- gestion de l’alphabet Base64,
- calcul des indices,
- opérations Vigenère mod 64,
- fonctions utilitaires communes.

---

## 6. Conclusion

Les programmes C constituent le cœur cryptographique de la boîte à outils.  
